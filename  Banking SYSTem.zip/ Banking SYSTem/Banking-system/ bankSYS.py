import datetime

class Account:
    def __init__(self, account_number, balance=0, interest_rate=0.01):
        self.account_number = account_number
        self.balance = balance
        self.interest_rate = interest_rate
        self.transaction_history = []

    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
            self.transaction_history.append(f"{datetime.datetime.now()}: Deposited: {amount}")
        else:
            print("Deposit amount should be greater than 0.")

    def withdraw(self, amount):
        if amount > 0:
            if self.balance >= amount:
                self.balance -= amount
                self.transaction_history.append(f"{datetime.datetime.now()}: Withdrawn: {amount}")
            else:
                print("Insufficient funds.")
        else:
            print("Withdrawal amount should be greater than 0.")

    def calculate_interest(self):
        interest_amount = self.balance * self.interest_rate
        self.balance += interest_amount
        self.transaction_history.append(f"{datetime.datetime.now()}: Interest: {interest_amount}")

    def get_balance(self):
        return self.balance

    def get_transaction_history(self):
        return self.transaction_history

    def generate_statement(self):
        statement = f"Account Statement for Account Number {self.account_number}:\n"
        statement += f"Current Balance: {self.balance}\n"
        statement += "Transaction History:\n"
        for transaction in self.transaction_history:
            statement += f"{transaction}\n"
        return statement


class Customer:
    def __init__(self, name, account):
        self.name = name
        self.account = account


class Bank:
    def __init__(self):
        self.customers = {}

    def create_account(self, name, account_number, initial_deposit=0):
        if account_number not in self.customers:
            account = Account(account_number, initial_deposit)
            customer = Customer(name, account)
            self.customers[account_number] = customer
        else:
            print("Account number already exists. Please use a different account number.")

    def get_customer(self, account_number):
        if account_number in self.customers:
            return self.customers[account_number]
        else:
            print("Customer not found.")

    def transfer(self, from_account, to_account, amount):
        if from_account in self.customers and to_account in self.customers:
            if amount > 0:
                if self.customers[from_account].account.balance >= amount:
                    self.customers[from_account].account.withdraw(amount)
                    self.customers[to_account].account.deposit(amount)
                    print("Transfer successful.")
                else:
                    print("Insufficient funds for transfer.")
            else:
                print("Transfer amount should be greater than 0.")
        else:
            print("One or both accounts not found.")

    def display_statement(self, account_number):
        if account_number in self.customers:
            account = self.customers[account_number].account
            statement = account.generate_statement()
            print(statement)
        else:
            print("Customer not found.")


if __name__ == "__main__":
    bank = Bank()

    bank.create_account("John Doe", 1001, 5000)
    bank.create_account("Jane Smith", 1002, 3000)

    bank.display_statement(1001)
    bank.display_statement(1002)

    bank.transfer(1001, 1002, 1000)

    bank.display_statement(1001)
    bank.display_statement(1002)

    bank.get_customer(1001).account.deposit(2000)
    bank.get_customer(1002).account.withdraw(500)

    bank.display_statement(1001)
    bank.display_statement(1002)
