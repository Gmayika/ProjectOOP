# Banking system
   Python project that simulates a basic banking system. This project will incorporate various object-oriented programming concepts and address the community issue of financial inclusion by providing a basic banking experience for users. We'll create three classes: Account, Customer, and Bank to demonstrate OOP concepts.
